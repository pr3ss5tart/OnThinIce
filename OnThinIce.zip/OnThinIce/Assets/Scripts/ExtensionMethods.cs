﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ExtensionMethods{

    //toVector2(): This takes a Vector3 and returns only the x and y vars of Vector3.
    public static Vector2 toVector2(this Vector3 v3)
    {
        return new Vector2(v3.x, v3.y);
    }
	
}
