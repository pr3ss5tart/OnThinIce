﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;

public class PlayerController : MonoBehaviour
{

    Rigidbody2D rb2d;
    public float moveForce = 5f;
    //public int iceBlocks = 0;
    public bool hasEgg;
    public bool canMove;

    // Use this for initialization
    void Start()
    {
        rb2d = this.GetComponent<Rigidbody2D>();
        hasEgg = false;
        canMove = true;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //This stops all other code in the FixedUpdate, thus freezing the game.
        if (!canMove)
        {
            return;
        }
        float moveHoriz = Input.GetAxis("Horizontal");
        float moveVert = Input.GetAxis("Vertical");
        Vector2 movement = new Vector2(moveHoriz, moveVert);

        //We include toVector2 because we only need the x&y vals.
        transform.LookAt(transform.position.toVector2() + movement);

        rb2d.AddForce(movement * moveForce);
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        //Iceblock
        if (col.gameObject.CompareTag("IceBlock") && (!hasEgg))
        {
            hasEgg = true;
            col.gameObject.SetActive(false);
        }
        else if (col.gameObject.CompareTag("IceBlock") && (hasEgg))
        {
            Debug.Log("You're already holding an iceblock dude!");
        }

        //Hazard
        if (col.gameObject.CompareTag("Hazard"))
        {
            this.gameObject.SetActive(false);
            Debug.Log("You died!!!");
        }
    }
}
