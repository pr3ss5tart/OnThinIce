﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NestManager : MonoBehaviour {

    public PlayerController player;

    public int eggCount;
    public int endEggCount;

	// Use this for initialization
	void Start () {
        player = FindObjectOfType<PlayerController>();
        eggCount = 0;
	}
	
	// Update is called once per frame
	void Update () {
        //This will move to the next scene.
		if(eggCount == endEggCount)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
	}

    private void OnTriggerEnter2D(Collider2D col)
    {
        //check if col is player and if player.hasEgg
        if(col.gameObject.CompareTag("Player") && player.hasEgg)
        {
            Debug.Log("You dropped off an egg!");
            eggCount++;
            player.hasEgg = false;
        }
        else if (col.gameObject.CompareTag("Player") && (!player.hasEgg))
        {
            Debug.Log("You need an iceblock dude!");
        }

    }
}
