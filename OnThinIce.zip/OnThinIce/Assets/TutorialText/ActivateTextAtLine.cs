﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivateTextAtLine : MonoBehaviour {

    public TextAsset theText;

    public int startLine;
    public int endLine;

    public TextManager textManager;
    public PlayerController player;

    public bool destroyWhenInactive;

	// Use this for initialization
	void Start () {
        textManager = FindObjectOfType<TextManager>();
        player = FindObjectOfType<PlayerController>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            //
            Debug.Log("Audio gods see you! They hear you!!!!");

            textManager.ReloadScript(theText); //Loads in assigned script
            textManager.currentLine = startLine;
            textManager.endLine = endLine;
            textManager.enableBox();
            player.canMove = true; //TEMP solution! This isn't how I want it to work in release.

            if (destroyWhenInactive)
            {
                gameObject.SetActive(false);

            }
        }
    }
}
