﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityStandardAssets.CrossPlatformInput;

public class TextManager : MonoBehaviour {

    public GameObject textBox;

    public Text theText;

    public TextAsset textFile;
    public string[] textLines;

    public int currentLine;
    public int endLine;

    public PlayerController player;

    public bool isActive;
    public bool stopPlayerMove;

    // Use this for initialization
    void Start()
    {
        player = FindObjectOfType<PlayerController>();

        if (textFile != null)
        {
            //Wooh Java!!! :D
            textLines = (textFile.text.Split('\n'));
        }

        if(endLine == 0)
        {
            //Stops at the end of the text.
            endLine = textLines.Length - 1;
        }

        if (isActive)
        {
            enableBox();
            stopPlayerMove = true;
        }
        else
        {
            disableBox();
            stopPlayerMove = false;
        }
    }

    void Update()
    {
        if (!isActive)
        {
            return;
        }

        theText.text = textLines[currentLine];

        if (Input.GetKeyDown(KeyCode.Return))
        {
            currentLine += 1;
            Debug.Log("CurrentLine: " + currentLine);
        }

        if(currentLine > endLine)
        {
            disableBox();
        }
    }

    public void enableBox()
    {
        textBox.SetActive(true);
        isActive = true;

        if (stopPlayerMove)
        {
            player.canMove = false;
        }
    }

    public void disableBox()
    {
        Debug.Log("disableBox funct call...");
        textBox.SetActive(false);
        isActive = false;

        if (!stopPlayerMove)
        {
            player.canMove = true;
        }
    }

    public void ReloadScript(TextAsset theText)
    {
        textLines = new string[1];
        textLines = (theText.text.Split('\n'));
    }
}
